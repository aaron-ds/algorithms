/**
 * Created by aarondesouza on 12/07/2015.
 */
public class Brute {

    public static void main(String[] args) {
        
    }
}
