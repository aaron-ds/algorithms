/**
 * Created by aarondesouza on 12/07/2015.
 */
public class Fast {

    public static void main(String[] args) {
        
    }
}
